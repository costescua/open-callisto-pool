
import { formatDifficulty } from 'open-social-pool/helpers/format-difficulty';
import { module, test } from 'qunit';

module('Unit | Helper | format difficulty');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = formatDifficulty([42]);
  assert.ok(result);
});

