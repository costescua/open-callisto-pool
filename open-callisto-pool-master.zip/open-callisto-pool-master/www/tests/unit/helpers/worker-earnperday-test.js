
import { workerEarnperday } from 'open-social-pool/helpers/worker-earnperday';
import { module, test } from 'qunit';

module('Unit | Helper | worker earnperday');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = workerEarnperday([42]);
  assert.ok(result);
});

