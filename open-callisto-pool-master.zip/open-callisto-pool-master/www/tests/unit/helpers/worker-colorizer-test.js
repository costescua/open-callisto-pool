
import { workerColorizer } from 'open-social-pool/helpers/worker-colorizer';
import { module, test } from 'qunit';

module('Unit | Helper | worker colorizer');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = workerColorizer([42]);
  assert.ok(result);
});

