# README
- These files are to help new users understand some of the vague instructions or if you want to see how others have setup there pools.
- Please modify the folder structure for your specific enviroment as these entries are just examples and will not work out of the box.

# JSON FILES
- Have been seperated as they should be with three pool setups added by default, these go with the PPLNS payout our fork uses.
- Some of the stuff in the jsons are redundant but doesn't matter as it's only looking for what is different.

# Accounts
- These files and the startpool.sh are tied together to unlock the pools account to process payments.

# Misc
- Various files added to help new users.
